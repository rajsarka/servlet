package com.cg.servletdemo;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ValidateLogin2")
public class ValidateLogin2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
    public ValidateLogin2() {
        super();
        // TODO Auto-generated constructor stub
    }

	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String unm=request.getParameter("txtUname1");
		String pwd=request.getParameter("txtPwd1");
		//PrintWriter pw=response.getWriter();
				
				if(unm.equalsIgnoreCase("admin")&& (pwd.equalsIgnoreCase("1234")))
				{
					
					RequestDispatcher rdSuccess=request.getRequestDispatcher("/Success2.html");
					rdSuccess.forward(request,response);
				}
				else
				{
					RequestDispatcher rfFailure=request.getRequestDispatcher("/Failure2.html");
					rfFailure.forward(request,response);
				}
					
	}
		
	}


